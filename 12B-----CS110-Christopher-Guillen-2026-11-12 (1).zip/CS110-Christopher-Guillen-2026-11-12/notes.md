# Christopher Guillen

# prep
repo: https://github.com/ChrisGuillen07/week12
video2: Observation: I found the idea of scope creep interesting because it shows how having too many creative ideas can actually hurt a project. Developers might start with a simple game idea but continue adding features until the game becomes too complicated to finish.

Useful Idea: Creating a clear plan before starting development can help prevent unnecessary features from taking over the original idea.

Question: How do developers decide when to stop adding new features and focus on finishing the game? AI used: ChatGPT
video3: Observation: I found the game development document interesting because it works almost like a blueprint for the entire game. It gives developers an organized place to keep track of the game's concept, requirements, resources, and other important information before they start building it.

Useful Idea: Having a game development document from the beginning can help prevent confusion and keep the project focused on its original idea.

Question: How often should developers update their game development document as new features and ideas are added? AI used: ChatGPT
gitTest: I tested my Git workflow by making a small change, saving it, and creating a commit. The commit worked fine without any errors. This showed me that Git was able to save and track my changes. I still need to make sure pushing the changes to the remote repository works correctly. AI used: ChatGPT
access: I tested my GitHub access and confirmed that it works fine. I was able to access my repository and check that everything was working. This means I can use GitHub to store my project, upload changes, and keep track of my work. I would also need to make sure my teammates and instructor have the correct access before working together.  AI used: ChatGPT
video1: Observation: I learned that making mistakes is a normal part of game development. Instead of giving up, developers should learn from their mistakes and try again.

Useful Idea: Every mistake is an opportunity to improve your skills and become a better developer.

Question: What should a developer do when they keep running into problems while making a game? AI used: ChatGPT
video4: Observation: Something I found interesting is that a folder structure can help new people understand a project without having to ask someone where every file is located. Using README files to explain what each folder contains can make it easier for someone to start helping with the game.

Useful Idea: I could include a short README inside folders for things like audio, images, and scripts so another person knows exactly what belongs there and where to find it.

Question: What information should be included in a README so a new team member can understand a project without needing someone to explain everything? AI used: ChatGPT
video5: Observation: I learned that deciding where files are stored and how they are backed up should happen early in development. This is important because losing important game assets, such as character models, music, or artwork, could cause a lot of problems.

Useful Idea: Keeping original assets separate from exported versions would help prevent accidentally replacing or losing the files I might need to edit later.

Question: What is the safest way to back up large game files so they can still be recovered if something goes wrong? AI used: ChatGPT
video6: Observation: I found it interesting that game development involves more than just one program. Developers may use different tools for coding, creating 3D models, editing text, communicating, and finding audio resources.

Useful Idea: Keeping links to useful programs and resources in one organized document would save time instead of having to search for the same tools every time I work on the game.

Question: How do developers decide which programs are worth using together instead of trying to do everything in one program? AI used: ChatGPT
opinion: I could use the game development pipeline to create an adventure game based on a futuristic bounty hunter app. In the game, players would take on the role of a bounty hunter who uses an app to find targets, accept missions, and earn rewards. Each mission would have a different target, location, and set of challenges. Some targets might be criminals hiding in crowded cities, while others could be difficult to track down in remote locations. I could use the pipeline to organize mission details, character designs, maps, dialogue, and rewards. As players complete more jobs, they could earn money to upgrade their equipment and unlock harder missions. This would help me create a game with a clear progression system and an interesting world for players to explore. AI used: ChatGPT
questions: Before committing to a team or mission for my bounty hunter game, I would want to know what everyone's responsibilities are and what the mission requires. I would ask how the team communicates, how rewards are divided, and what happens if someone cannot complete their part. I would also want to know how difficult the mission is, what equipment is needed, and whether there are any risks or unexpected challenges. Having these questions answered beforehand would help prevent confusion, keep everyone working toward the same goal, and make missions run more smoothly. AI used: ChatGPT

# prepBoard
notes: AI used: ChatGPT

## pen
color: #153f48
size: 1

# pitch
understand: The job is to take my bounty hunter game idea and turn it into a working game that people can actually play. This means planning the missions, designing the characters and city, creating the bounty hunting app, and programming features like target tracking, rewards, and equipment upgrades. I would also need to test the game, fix bugs, and make sure missions work the way they are supposed to. The finish line is having a complete game where players can accept bounties, track down targets, complete missions, earn money, and use their rewards to improve their equipment. It is not just about having a good idea; it is about finishing a playable game that works. AI used: ChatGPT
offer: I can contribute creative ideas, help plan missions, and think of ways to make the bounty hunter game more interesting. I can help come up with different targets, mission objectives, rewards, and challenges for players to complete. I can also help organize the project, give feedback on ideas, and test the game to find problems. I would be willing to communicate with my teammates, listen to their suggestions, and help wherever I am needed to get the game finished. AI used: ChatGPT
limits: I still need to learn more about programming and how to build the different systems in my bounty hunter game. I would need to practice creating the bounty app, setting up missions, making targets move around the map, and programming the reward system. I also need to learn how to design maps and characters and add sound effects. Getting more experience with game development programs and learning how to fix coding errors would help me turn my ideas into an actual playable game. I would also benefit from guidance from teammates who have more experience with programming and game design. AI used: ChatGPT
availability: 2026-11-10 16:00–17:00 Pacific
2026-11-12 16:00–17:00 Pacific
2026-11-13 18:00–23:00 Pacific
2026-11-13 12:00–23:00 Pacific
Preferred contact: Classroom
tools: 1. XAML: I would use XAML to design the layout of the bounty hunter app, including buttons, menus, mission lists, and target information.

2. Unity: I would use Unity to create the actual game, build the city, program missions, and make the bounty hunting mechanics work.

3. Discord: I would use Discord to communicate with teammates, share ideas, send updates, and discuss problems during development.

4. Canvas: I would use Canvas to access class assignments, follow project instructions, submit completed work, and keep track of deadlines and feedback from my professor.

AI used: ChatGPT
aiTool: AI: ChatGPT and Claude
Task: I will use ChatGPT and Claude to brainstorm bounty hunting missions, create target descriptions, come up with game features, organize ideas, and help me understand coding problems while developing my game in Unity.
Verification: I will compare their suggestions, check that the information makes sense, and test any code in Unity to make sure it works. I will also make sure their ideas fit my game and correct anything that is inaccurate or does not work.

# availability
notes: 

## slots

### 0
id: b5834b46-b379-4008-b528-b6109c702ded
date: 2026-11-10
start: 16:00
end: 17:00

### 1
id: fc83f2d1-cddd-47eb-b231-a15cdc2c5186
date: 2026-11-12
start: 16:00
end: 17:00

### 2
id: 1819ee5e-7d3f-4f74-86f9-2fd110b51fcf
date: 2026-11-13
start: 18:00
end: 23:00

### 3
id: 2a803625-b01d-4bae-b903-008d895d14b1
date: 2026-11-13
start: 12:00
end: 23:00

# aiPlan
name: ChatGPT and Claude
task: I will use ChatGPT and Claude to brainstorm bounty hunting missions, create target descriptions, come up with game features, organize ideas, and help me understand coding problems while developing my game in Unity.
verify: I will compare their suggestions, check that the information makes sense, and test any code in Unity to make sure it works. I will also make sure their ideas fit my game and correct anything that is inaccurate or does not work.

# huddle
mission: We are going to convert the Bounty Hunting App into a game where the player will actually hunt for the criminals.
framework: We chose P2P.
pipeline: Unnamed stage
Unnamed stage
Unnamed stage
Unnamed stage
Unnamed stage
Unnamed stage
Placeholder · owner Bounty Sketch 
Placeholder · owner Connector
We put everything in order and used Claude Ai to give us the answers
tech: Engine: Unity. It’s free, lightweight, and has good beginner tutorials, so everyone can install it and start quickly.

Language: Unity C#. It’s built into Godot and easy to read, so teammates can understand each other’s code.

Packages/add-ons: Godot’s built-in 2D/3D tools (sprites, collision, UI nodes) so we don’t depend on extra downloads that might break.

Assets: Free, license-friendly art and sound (for example from Kenney.nl or OpenGameArt), plus our own wanted-poster designs made in Canva or Figma. We chose free assets so we don’t have copyright problems.

Who checks them:

[Leah Aluni] checks that the engine and code run on every team member’s computer.
[Nicolas Kuhnast] checks that every asset has a license that lets us use it.
[George Arbache] tests the finished build after each change.

Why we chose these: They’re free, beginner-friendly, and work well for a small team with limited time. Open question: Do we need any extra add-ons for saving scores, or is the built-in system enough? I used Claude to get the answer
code: Start / Update
Callback | What happens | Verified
Awake() | Sets up references (player, bounty list) before the game starts | [x]
Start() | Loads the first bounty and sets the score to 0 | [x]
Update() | Every frame: reads player input, moves the player, checks if the bounty is caught | [x]
OnCollisionEnter2D() | Runs when the player touches a bounty target, then adds the reward to the score | [x]

Classes & components
Class | Responsibility | GameObject
PlayerController | Reads input and moves the player; checks when the player touches a bounty | Player
BountyTarget | Stores each target’s name, difficulty, and reward value | Bounty (prefab)
GameManager | Tracks the score and which bounty is active; decides when the game ends | GameManager (empty object)
UIManager | Updates the score text and shows the win or game over screen | Canvas

Packages / using
Package / namespace | Why included | Tested
using UnityEngine; | Gives access to the core engine tools our scripts need, like MonoBehaviour, Transform, Input, and Vector2 | [x]
using UnityEngine.UI; | Lets us update the score text and buttons on the screen from code | [x]
using System.Collections.Generic; | Lets us use List<> to store the bounty list and loop through it | [x]
using UnityEngine.SceneManagement; | Lets us reload the scene when the player restarts after winning or losing | [x]
communication: Team check-ins
Description / contact / owner | When · Pacific | Agreed
George Arbache  | 2026-11-10T15:48 | [x]
reuse: PlayerController script (our own code). Source: written by our team. Credit: none required, but we’ll keep our names in the code comments.
GameManager and score system (our own code). Source: written by our team. Credit: none required. It can be reused for any game that tracks points or objectives.
Bounty data structure (BountyTarget class). Source: our team. Credit: none required. We can swap in new characters, rewards, and difficulty levels for a new story.
Free art and sound assets (for example from Kenney.nl or OpenGameArt). Source: the website and creator’s name, saved in a credits file. Credit: we’ll check each license, since some (CC0) need no credit and others (CC-BY) require us to name the creator.
Our wanted-poster and menu designs (Canva or Figma). Source: our team. Credit: if we used Canva templates or stock elements, we’ll check Canva’s license terms before reusing them. I used Claude for my answer.
boardNotes: What the huddle board is: A shared space where our team writes down what we discussed, what we agreed on, and what we still need to figure out, so nobody has to rely on memory and everyone can see the same plan.

Decisions we made:

We will build the game in [Godot/Unity] using [GDScript/C#], because it’s free and beginner-friendly.
We will keep the game small: at least 3 bounties, a score system, and a win or game over screen.
We will use free, license-friendly assets and keep a credits file listing each source.
Each person owns one part of the pipeline: [Name 1] inputs, [Name 2] building, [Name 3] design, [Name 4] testing.

Disagreements:

Some of us wanted more bounties and extra levels, while others wanted to finish a smaller game that works. We agreed to finish 3 bounties first and add more only if time is left.
We discussed whether to draw our own art or use free assets. We chose free assets for the characters and made our own wanted posters.

Questions that remain open:

Do we need an extra add-on to save high scores, or is the built-in system enough?
Who will double-check that every asset’s license allows us to reuse it?
How many classmates can test the game before the deadline? I used Claude to get the answers

## board
notes: Our mission is to build a playable bounty hunting game with at least three bounties, a score system, and a win or game over screen. In our huddle we compared our ideas for the mission and agreed to keep the game small so we can finish it.

The diagram shows the mission at the top, connected to three jobs. [Name 1] builds the game and scoring. [Name 2] designs the posters, menus, and art. [Name 3] tests the game, keeps the bug list, and checks that every asset’s license lets us use it. All three jobs lead to the finished prototype at the bottom.

We decided that each person owns one job so nothing is missed, and that we will check in again before the deadline. One disagreement was whether to add more bounties or finish a smaller game first, and we chose to finish three bounties first. One open question is how we will save high scores. we used claude to get the answers

## pipelineBoard
notes: We put everything in order and used Claude Ai to give us the answers

## codeTables

### 0
id: f755df56-99d0-432a-9e1f-74ecc1902297
title: Start / Update

#### columns

##### 0
label: Callback
type: text

##### 1
label: What happens
type: text

##### 2
label: Verified
type: checkbox

#### rows

##### 0
0: Awake()
1: Sets up references (player, bounty list) before the game starts
2: true

##### 1
0: Start()
1: Loads the first bounty and sets the score to 0
2: true

##### 2
0: Update()
1: Every frame: reads player input, moves the player, checks if the bounty is caught
2: true

##### 3
0: OnCollisionEnter2D()
1: Runs when the player touches a bounty target, then adds the reward to the score
2: true

### 1
id: c0b5405d-1eba-4c5e-8cd3-c3785ef3b8e8
title: Classes & components

#### columns

##### 0
label: Class
type: text

##### 1
label: Responsibility
type: text

##### 2
label: GameObject
type: text

#### rows

##### 0
0: PlayerController
1: Reads input and moves the player; checks when the player touches a bounty
2: Player

##### 1
0: BountyTarget
1: Stores each target’s name, difficulty, and reward value
2: Bounty (prefab)

##### 2
0: GameManager
1: Tracks the score and which bounty is active; decides when the game ends
2: GameManager (empty object)

##### 3
0: UIManager
1: Updates the score text and shows the win or game over screen
2: Canvas

### 2
id: 964a5672-74ca-40a8-8427-ccc9b1295e38
title: Packages / using

#### columns

##### 0
label: Package / namespace
type: text

##### 1
label: Why included
type: text

##### 2
label: Tested
type: checkbox

#### rows

##### 0
0: using UnityEngine;
1: Gives access to the core engine tools our scripts need, like MonoBehaviour, Transform, Input, and Vector2
2: true

##### 1
0: using UnityEngine.UI;
1: Lets us update the score text and buttons on the screen from code
2: true

##### 2
0: using System.Collections.Generic;
1: Lets us use List<> to store the bounty list and loop through it
2: true

##### 3
0: using UnityEngine.SceneManagement;
1: Lets us reload the scene when the player restarts after winning or losing
2: true

## communicationTables

### 0
id: 94fbcf11-58d1-405b-b8c3-f121cee8b18c
title: Team check-ins

#### columns

##### 0
label: Description / contact / owner
type: text

##### 1
label: When · Pacific
type: datetime-local

##### 2
label: Agreed
type: checkbox

#### rows

##### 0
0: George Arbache 
1: 2026-11-10T15:48
2: true

# huddleBoard
notes: Our mission is to build a playable bounty hunting game with at least three bounties, a score system, and a win or game over screen. In our huddle we compared our ideas for the mission and agreed to keep the game small so we can finish it.

The diagram shows the mission at the top, connected to three jobs. [Name 1] builds the game and scoring. [Name 2] designs the posters, menus, and art. [Name 3] tests the game, keeps the bug list, and checks that every asset’s license lets us use it. All three jobs lead to the finished prototype at the bottom.

We decided that each person owns one job so nothing is missed, and that we will check in again before the deadline. One disagreement was whether to add more bounties or finish a smaller game first, and we chose to finish three bounties first. One open question is how we will save high scores. we used claude to get the answers

# pipelineBoard
notes: We put everything in order and used Claude Ai to give us the answers

# codeTables

## 0
id: f755df56-99d0-432a-9e1f-74ecc1902297
title: Start / Update

### columns

#### 0
label: Callback
type: text

#### 1
label: What happens
type: text

#### 2
label: Verified
type: checkbox

### rows

#### 0
0: Awake()
1: Sets up references (player, bounty list) before the game starts
2: true

#### 1
0: Start()
1: Loads the first bounty and sets the score to 0
2: true

#### 2
0: Update()
1: Every frame: reads player input, moves the player, checks if the bounty is caught
2: true

#### 3
0: OnCollisionEnter2D()
1: Runs when the player touches a bounty target, then adds the reward to the score
2: true

## 1
id: c0b5405d-1eba-4c5e-8cd3-c3785ef3b8e8
title: Classes & components

### columns

#### 0
label: Class
type: text

#### 1
label: Responsibility
type: text

#### 2
label: GameObject
type: text

### rows

#### 0
0: PlayerController
1: Reads input and moves the player; checks when the player touches a bounty
2: Player

#### 1
0: BountyTarget
1: Stores each target’s name, difficulty, and reward value
2: Bounty (prefab)

#### 2
0: GameManager
1: Tracks the score and which bounty is active; decides when the game ends
2: GameManager (empty object)

#### 3
0: UIManager
1: Updates the score text and shows the win or game over screen
2: Canvas

## 2
id: 964a5672-74ca-40a8-8427-ccc9b1295e38
title: Packages / using

### columns

#### 0
label: Package / namespace
type: text

#### 1
label: Why included
type: text

#### 2
label: Tested
type: checkbox

### rows

#### 0
0: using UnityEngine;
1: Gives access to the core engine tools our scripts need, like MonoBehaviour, Transform, Input, and Vector2
2: true

#### 1
0: using UnityEngine.UI;
1: Lets us update the score text and buttons on the screen from code
2: true

#### 2
0: using System.Collections.Generic;
1: Lets us use List<> to store the bounty list and loop through it
2: true

#### 3
0: using UnityEngine.SceneManagement;
1: Lets us reload the scene when the player restarts after winning or losing
2: true

# communicationTables

## 0
id: 94fbcf11-58d1-405b-b8c3-f121cee8b18c
title: Team check-ins

### columns

#### 0
label: Description / contact / owner
type: text

#### 1
label: When · Pacific
type: datetime-local

#### 2
label: Agreed
type: checkbox

### rows

#### 0
0: George Arbache 
1: 2026-11-10T15:48
2: true

# tasks

## 0
id: e9fcadfb-346c-4e46-81be-35b6fba97260
task: make assest
owner: PERSON-2CF9BDAD78338B9BDDA6928E
due: 2026-11-12T20:30
done: false
result: 

## 1
id: ab8b7007-c585-474b-b404-450d07460f53
task: do the coding
owner: PERSON-2CF9BDAD78338B9BDDA6928E
due: 2026-11-12T20:30
done: false
result: 

## 2
id: 5019ca2c-a540-4466-82bc-74fac46c30e6
task: Organize information
owner: PERSON-C74E56D4FBB64FE2EB6D0CC8
due: 2026-11-12T20:30
done: false
result: 

# previousTeamPlans

## 0
team: TEAM-BE6A42D9973ABA2940DFA478
name: Human Systems Check

### huddle
mission: A Bounty Hunter in a cyberpunk type world hunting down all the bounties he can of different creatures
framework: P2P
pipeline: Story goal · 2026-11-10T12:45 to 2026-11-10T13:45 Pacific
Inputs / assets · 2026-11-10T13:45 to 2026-11-10T14:45 Pacific
Build + configure · 2026-11-10T14:45 to 2026-11-10T15:45 Pacific
Output / scene · 2026-11-10T15:45 to 2026-11-10T16:45 Pacific
Test + handoff · 2026-11-10T16:45 to 2026-11-10T17:45 Pacific
New stage · 2026-11-10T17:45 to 2026-11-10T18:45 Pacific
New stage · 2026-11-10T18:45 to 2026-11-10T19:45 Pacific
We are going to make a Pathways to pipelines 
type game
tech: Unity, C#, Characters
code: Classes & components
Class | Responsibility | GameObject
te | te | te
communication: Working agreements
Agreement | Owner / where recorded | Confirmed
te | te | [ ]
reuse: The assets
boardNotes: We explained everyone works

#### board
notes: Make a AR Game that helps others catch bounties and try to get the best version of that creature

#### pipelineBoard
notes: We are going to make a Pathways to pipelines 
type game

#### codeTables

##### 0
id: 33d6291c-2d2f-4be6-8eef-def08a5fbba1
title: Classes & components

##### columns

##### 0
label: Class
type: text

##### 1
label: Responsibility
type: text

##### 2
label: GameObject
type: text

##### rows

##### 0
0: te
1: te
2: te

#### communicationTables

##### 0
id: 2a432ee5-bb48-456c-9515-9c5b2832b853
title: Working agreements

##### columns

##### 0
label: Agreement
type: text

##### 1
label: Owner / where recorded
type: text

##### 2
label: Confirmed
type: checkbox

##### rows

##### 0
0: te
1: te
2: false

### huddleBoard
notes: Make a AR Game that helps others catch bounties and try to get the best version of that creature

### pipelineBoard
notes: We are going to make a Pathways to pipelines 
type game

### codeTables

#### 0
id: 33d6291c-2d2f-4be6-8eef-def08a5fbba1
title: Classes & components

##### columns

##### 0
label: Class
type: text

##### 1
label: Responsibility
type: text

##### 2
label: GameObject
type: text

##### rows

##### 0
0: te
1: te
2: te

### communicationTables

#### 0
id: 2a432ee5-bb48-456c-9515-9c5b2832b853
title: Working agreements

##### columns

##### 0
label: Agreement
type: text

##### 1
label: Owner / where recorded
type: text

##### 2
label: Confirmed
type: checkbox

##### rows

##### 0
0: te
1: te
2: false

### tasks

#### 0
id: 21d08324-4500-4823-bd60-db6c5a0d782e
task: 
owner: PERSON-0134466E7594E128639BDB00
due: 2026-11-12T20:30
done: false
result: 

# dayBReview
recap: I understand that our main goal is to turn the Bounty Hunting App into a playable video game using Unity and C#. In our game, players will be able to explore different locations, search for wanted criminals, chase them, and capture them to complete missions and earn rewards. We want to create an interactive experience where players can control their character, interact with the environment, and complete different bounty hunting objectives.

My responsibility is to help my team plan, design, and program the game, especially the player movement and criminal capture systems. I plan to learn how to use Unity's GameObjects, components, and C# scripts to create a character that can walk, run, and interact with other objects. I also want to help develop a system where criminals can move around the map and react when the player approaches them. For example, criminals could attempt to escape, requiring the player to chase them before making a capture.

Another important part of our project is creating the capture mechanics. We need to decide how close the player must be to a criminal and what action they must perform to capture them. We could use Unity's collision detection system or distance calculations to determine when a criminal is within capture range. After a successful capture, the game could display a notification, update the player's mission progress, and award points or money.

We will also use a project board to organize our responsibilities and track our development progress. The board will separate tasks into categories such as To Do, In Progress, Testing, and Completed. This will help our team understand which features still need to be developed and which ones are ready for testing. We also plan to use GitHub to save our Unity project files, track code changes, and collaborate with teammates.

There are still several important decisions we need to make. We need to determine whether the game will be 2D or 3D, how the player controls will work, how criminals will behave, and how missions will be completed. We also need to decide which teammates will be responsible for programming, designing the environment, creating the user interface, and testing the game.

My next priority is to help create a simple playable prototype in Unity. The prototype should allow a player to move around a basic environment, locate a criminal, and perform a capture action. Once these basic mechanics are working, our team can begin adding more advanced features such as criminal AI, multiple missions, different locations, and a reward system. I understand that developing the game will require teamwork, problem-solving, testing, and learning more about Unity and C# programming.mechanics will work, which tools we will use, and what each teammate will be responsible for. AI used: ChatGPT
goal: true
owners: true
blockers: true
notes: Nothng so far.
returnToB: false

# reportA
checkpoint: I understand that our main goal is to transform the Bounty Hunting App into an interactive video game using **Unity and C# programming**. Instead of just having an app that displays information about criminals, we want to create a game where players can explore an environment, search for wanted criminals, chase them, and capture them to complete missions and earn rewards.

My responsibility is to help my team plan, design, and develop the game using Unity. I want to focus on learning how to create a playable character, program movement controls, and develop the basic mechanics needed to interact with criminals. In Unity, we can use GameObjects to represent characters and objects, components to control their behavior, and C# scripts to program actions such as walking, running, interacting, and capturing criminals. We will also need to create a map where players can explore different locations and find their targets.

Another important part of the project is developing the criminal characters. We need to decide how criminals will behave when the player approaches them. For example, criminals could run away, hide, or move around the map. We could use Unity's NavMesh navigation system to help criminals move through the environment. We also need to create a capture system that allows the player to arrest a criminal when they get close enough or complete a specific action.

I also understand that teamwork and organization are important. We can use GitHub to save our Unity project, track changes to our code, and collaborate with teammates. Our project board will help us organize tasks into categories such as To Do, In Progress, Testing, and Completed. We should begin by creating a simple playable prototype before adding more complicated features.

Some questions I still need to clarify are whether our game will be 2D or 3D, whether we will use first-person or third-person movement, how criminals will react to the player, and what conditions must be met to successfully capture them. I also want to learn more about connecting C# scripts to Unity GameObjects, using physics and collision detection, and testing our code to fix errors.

Overall, I understand that our first priority should be creating a basic Unity game where the player can move around, locate a criminal, and capture them. Once those features work correctly, we can expand the game by adding more criminals, different missions, rewards, improved graphics, and additional gameplay mechanics. AI used: ChatGPT
evidence: I worked on planning our Bounty Hunting Game, which we plan to develop using Unity and C#. The main goal is to create an interactive game where players can explore a map, search for wanted criminals, chase them, and capture them to complete missions. I helped identify important gameplay features, including player movement, criminal behavior, a capture system, and a mission and reward system.

I also worked on organizing our project board to show the tasks we need to complete, the responsibilities of team members, and the steps involved in developing the game. We plan to use Unity's GameObjects and components to create characters and environments, while C# scripts will control player movement, criminal interactions, and gameplay mechanics. We may also use Unity's physics and collision detection systems to determine when players interact with criminals.

One important decision is to begin with a simple playable prototype before developing more advanced features. Our first goal is to create a character that can move around a basic environment and interact with a criminal. After that, we can work on criminal AI, capture mechanics, missions, and rewards.

We still need to finalize how the gameplay will work, assign specific programming tasks, and decide how to organize our Unity project files. My next step is to save our planning documents and project files to GitHub, create a commit to record our progress, and organize our notes, project board, and team documents so everyone can access them. I also want to learn more about using C# scripts in Unity and testing our gameplay features to identify and fix programming errors. AI used: ChatGPT
next: My next task is to help develop our Bounty Hunting Game using Unity and C#. I plan to focus on creating the basic player movement system and developing the mechanics that will allow players to find, chase, and capture criminals. I will start by creating a player GameObject in Unity and using C# scripts to control movement, including walking, running, and changing directions. I also want to experiment with Unity's collision detection system so the player can interact with criminals when they get close enough.

After creating the movement system, I plan to work on a basic criminal capture mechanic. This could involve programming a criminal character that moves around the map and allowing the player to capture the criminal by pressing a specific key when within a certain distance. I will also need to test these features in Unity's Play Mode to make sure the controls work correctly and the capture system responds as expected.

My goal is to make progress on these features before our next class deadline. One possible blocker is that I am still learning how to write C# scripts and connect them to GameObjects in Unity. I might also encounter problems with movement, collisions, or programming the criminal's behavior.

If I run into difficulties, I will review Unity tutorials, study C# programming examples, ask my teammates for assistance, and experiment with different solutions. I will use Unity's Console window to identify errors and debug my scripts. Once the features are working, I plan to save my progress, upload the updated project files to GitHub, and document what I completed, what problems I encountered, and what still needs improvement. My main priority is to help create a simple playable prototype that we can continue improving as a team. AI used: ChatGPT

# reportABoard
notes: The Bounty Hunting Game Board is a visual plan showing what your team wants to create, what needs to be done, and how you will organize the work.
1. Project Goal
Your team is turning the Bounty Hunting App into a video game where players search for criminals, chase them, and capture them.
2. My Recap
This section explains your understanding of the project and your responsibilities. Your job is to help plan, design, and program the game with your teammates.
3. Team Board (Kanban)
The four columns organize the project's progress:
- To Do: Tasks that haven't been started, such as designing criminals, creating the map, and adding game features.
- In Progress: Tasks currently being worked on, such as player movement and capturing criminals.
- Review/Testing: Features that need to be tested to make sure they work.
- Done: Planning activities that have been completed.
4. Next Task and Plan
Your next task is to work on player movement and criminal capture mechanics before the next class deadline.

If you encounter programming problems, you can watch tutorials, ask teammates for help, or try different solutions.
5. Team Roles
The board suggests dividing responsibilities among teammates, including programming, game design, map creation, and testing. These are proposed roles, not confirmed assignments.
6. Tools and Resources
The board includes Unity for creating the game, C# for programming, GitHub for saving code, and shared documents for recording progress.

Important: The board is a proposed project plan. Tasks shown as completed or in progress should be updated to match what your team has actually done. AI used: ChatGPT 

## pen
color: #153f48
size: 1

# reportB
execution: I created a detailed project board for our Bounty Hunting Game to help organize our goals, development tasks, team responsibilities, and next steps. Our main objective is to transform the original Bounty Hunting App into an interactive video game using Unity and C#. In the game, players will be able to explore different environments, search for wanted criminals, chase them, and capture them to complete missions and earn rewards.

The project board organizes our development process into four main categories: To Do, In Progress, Testing, and Completed. I included important tasks such as creating player movement controls, programming criminal behavior, developing capture mechanics, designing the game map, and testing gameplay features. This organization will help our team understand what needs to be completed, what we are currently working on, and what requires additional improvements.

I also identified the programming tools and systems we may need to develop the game. We plan to use Unity as our game engine and C# to program the gameplay mechanics. Unity's GameObjects and components will allow us to create characters, environments, and interactive objects. C# scripts will help us control player movement, criminal behavior, and the capture system. We may also use Unity's physics and collision detection features to determine when players interact with criminals.

Another important part of my planning was identifying possible programming challenges. Some difficulties we might encounter include writing C# scripts correctly, making characters move smoothly, programming criminals to escape from the player, and ensuring the capture system works properly. To overcome these challenges, I plan to review Unity tutorials, experiment with different programming solutions, use the Unity Console to identify errors, and communicate with my teammates when I need assistance.

Our next step is to begin developing a basic playable prototype in Unity. We should start by creating a simple environment and a player character that can move around using keyboard controls. After that, we can add a criminal character and develop a basic capture system that allows the player to arrest the criminal when they are within a certain distance. Once these features are implemented, we will test them in Unity's Play Mode, identify any bugs, and make improvements.

I also plan to use GitHub to save our project files, track changes, and document our development progress. Overall, creating the project board helped me better understand the steps required to develop our game and how we can divide the work among team members. It gives us a clear development plan and will help us stay organized as we continue building and improving our Bounty Hunting Game. AI used: ChatGPT
tests: I created a project board for our Bounty Hunting Game to organize the different tasks and features we need to develop using Unity and C#. The board includes important parts of the game, such as player movement, criminal capture mechanics, map design, criminal behavior, and gameplay testing. I organized these tasks into categories such as To Do, In Progress, Testing, and Completed so our team can keep track of our progress and understand what still needs to be done.

Although I have completed the initial planning and organization of our project, I have not tested the actual game in Unity yet. My next step is to make sure our Unity project opens correctly, that the game scene loads without errors, and that the basic gameplay features function as intended. I plan to use Unity's Play Mode to test the game and the Console window to check for programming errors or warnings.

One of the first features I want to test is player movement. We plan to use C# scripts to allow the player to move around the environment using keyboard controls. I will need to check whether the character moves in the correct directions, responds properly to player input, and interacts with the environment without unexpected problems. If we use Unity's Rigidbody or Character Controller components, I will also need to make sure movement and collision detection work correctly.

Another important feature to develop and test is the criminal capture system. Our goal is to allow players to locate criminals, chase them, and capture them when they are within a certain distance. We could use C# scripts and Unity's collision detection or distance calculations to determine when a criminal is close enough to capture. I will need to test whether the capture action activates correctly, whether the criminal is registered as captured, and whether the game updates the mission progress.

I also plan to test the game environment to make sure the player can move around the map without getting stuck or passing through objects. If we add criminal AI, we will need to check whether criminals move correctly and react when the player approaches them. These tests will help us identify problems before adding more advanced gameplay features.

If something does not work correctly, I will try to identify the cause by reviewing the C# scripts, checking the Unity Inspector settings, and reading error messages in the Console. After making changes, I will run the game again to see whether the problem has been fixed. I will document what worked, what failed, what changes were made, and whether the retest was successful.

My next priority is to help build a simple playable prototype where the player can move around a basic environment, find a criminal, and perform a capture action. Once we have tested these basic features successfully, our team can begin adding more advanced mechanics, including criminal AI, additional missions, rewards, and improved map design. I also plan to save our progress to GitHub so we can track changes and collaborate more effectively.

Overall, the project board has helped me understand the development process and prepare for the testing stage. While we have completed some of the planning work, we still need to implement and verify the actual gameplay systems. Our goal is to make sure the basic mechanics work correctly before expanding the game further. AI used: ChatGPT
handoff: I created a project board for our Bounty Hunting Game to organize the different tasks and features we need to develop using Unity and C#. The board includes important parts of the game, such as player movement, criminal capture mechanics, map design, criminal behavior, and gameplay testing. I organized these tasks into categories such as To Do, In Progress, Testing, and Completed so our team can keep track of our progress and understand what still needs to be done.

Although I have completed the initial planning and organization of our project, I have not tested the actual game in Unity yet. My next step is to make sure our Unity project opens correctly, that the game scene loads without errors, and that the basic gameplay features function as intended. I plan to use Unity's Play Mode to test the game and the Console window to check for programming errors or warnings.

One of the first features I want to test is player movement. We plan to use C# scripts to allow the player to move around the environment using keyboard controls. I will need to check whether the character moves in the correct directions, responds properly to player input, and interacts with the environment without unexpected problems. If we use Unity's Rigidbody or Character Controller components, I will also need to make sure movement and collision detection work correctly.

Another important feature to develop and test is the criminal capture system. Our goal is to allow players to locate criminals, chase them, and capture them when they are within a certain distance. We could use C# scripts and Unity's collision detection or distance calculations to determine when a criminal is close enough to capture. I will need to test whether the capture action activates correctly, whether the criminal is registered as captured, and whether the game updates the mission progress.

I also plan to test the game environment to make sure the player can move around the map without getting stuck or passing through objects. If we add criminal AI, we will need to check whether criminals move correctly and react when the player approaches them. These tests will help us identify problems before adding more advanced gameplay features.

If something does not work correctly, I will try to identify the cause by reviewing the C# scripts, checking the Unity Inspector settings, and reading error messages in the Console. After making changes, I will run the game again to see whether the problem has been fixed. I will document what worked, what failed, what changes were made, and whether the retest was successful.

My next priority is to help build a simple playable prototype where the player can move around a basic environment, find a criminal, and perform a capture action. Once we have tested these basic features successfully, our team can begin adding more advanced mechanics, including criminal AI, additional missions, rewards, and improved map design. I also plan to save our progress to GitHub so we can track changes and collaborate more effectively.

Overall, the project board has helped me understand the development process and prepare for the testing stage. While we have completed some of the planning work, we still need to implement and verify the actual gameplay systems. Our goal is to make sure the basic mechanics work correctly before expanding the game further. AI used: ChatGPT
reflection: I created a project board for our Bounty Hunting Game and compared it with our original goal of developing an interactive video game where players can search for, chase, and capture wanted criminals. Our team plans to use Unity as the main game engine and C# as the programming language to create the gameplay mechanics. By reviewing our project board, I was able to confirm that our development plan includes the important features needed to make the game playable, such as player movement, criminal capture mechanics, map design, criminal behavior, and gameplay testing.

One of the main things I verified was that our project plan focuses on creating the basic gameplay features before adding more advanced systems. For example, we need to create a player character in Unity that can move around the environment using keyboard controls. We also need to develop a criminal character that the player can locate and capture. These features will require us to use Unity's GameObjects, components, and C# scripts to control how characters move and interact with each other.

I also reviewed our plans for the criminal capture system. We want players to be able to approach criminals and perform a capture action when they are within a certain distance. One possible solution is to use Unity's collision detection system or C# distance calculations to determine when a criminal is close enough to capture. After a successful capture, the game could display a message, update the mission objectives, and reward the player with points or money.

Another important part of reviewing our project was checking whether we had included enough time for testing and debugging. Although we have organized the development tasks, we still need to build and test the actual gameplay features in Unity. We will need to use Unity's Play Mode to check player movement, criminal interactions, and the capture system. If something does not work correctly, we can use the Unity Console to identify programming errors, review our C# scripts, make corrections, and test the game again.

One useful discovery I made during this activity is that organizing our project into smaller tasks makes the development process easier to understand and manage. Instead of trying to create the entire game at once, we can focus on completing one feature at a time. Our project board helps us identify which tasks need to be started, which ones are currently being developed, which ones require testing, and which ones have been completed. It also helps us divide responsibilities among teammates and communicate about our progress.

I also realized that some parts of our original plan need more clarification. For example, we still need to decide whether the game will be 2D or 3D, how criminals will move around the environment, how the player will interact with them, and what conditions will determine whether a capture is successful. These decisions will affect how we organize our Unity scenes, GameObjects, and C# scripts.

Our team's next step should be to create a simple playable prototype in Unity. We can begin by building a basic map, adding a player character, and programming movement controls. Once the player can move correctly, we can add a criminal character and develop a basic capture mechanic. After implementing these features, we will test them, identify any problems, and make improvements before adding more advanced features such as criminal AI, multiple missions, rewards, and additional environments.

We also plan to use GitHub to save our Unity project files, track changes to our code, and collaborate with teammates. This will allow us to document our progress and return to earlier versions if we encounter problems.

Overall, reviewing our project board helped me confirm that our development plan is connected to the original goals of the Bounty Hunting Game. I learned that planning, organization, teamwork, and testing are important parts of game development. Although our basic gameplay systems have not been fully developed or tested yet, we now have a clearer understanding of what needs to be completed and how we can approach the next stage of building our game in Unity. AI used: ChatGPT

# reportBBoard
notes: This image shows the project board I created for our Bounty Hunting Game. It explains our goal of making a game where players hunt down and capture criminals. I organized the work into tasks that need to be completed, tasks planned for development, testing, and completed planning activities. The board also includes proposed team responsibilities and the tools we may use. My main focus is helping develop player movement and criminal capture mechanics. This board helps us understand our next steps and stay organized while building the game. AI used: ChatGPT