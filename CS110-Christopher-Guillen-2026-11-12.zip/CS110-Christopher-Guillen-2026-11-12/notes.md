# Christopher Guillen

# prep
repo: https://github.com/ChrisGuillen07/week12
video2: Observation: I found the idea of scope creep interesting because it shows how having too many creative ideas can actually hurt a project. Developers might start with a simple game idea but continue adding features until the game becomes too complicated to finish.

Useful Idea: Creating a clear plan before starting development can help prevent unnecessary features from taking over the original idea.

Question: How do developers decide when to stop adding new features and focus on finishing the game? AI used: ChatGPT
video3: Observation: I found the game development document interesting because it works almost like a blueprint for the entire game. It gives developers an organized place to keep track of the game's concept, requirements, resources, and other important information before they start building it.

Useful Idea: Having a game development document from the beginning can help prevent confusion and keep the project focused on its original idea.

Question: How often should developers update their game development document as new features and ideas are added? AI used: ChatGPT
gitTest: I tested my Git workflow by making a small change, saving it, and creating a commit. The commit worked fine without any errors. This showed me that Git was able to save and track my changes. I still need to make sure pushing the changes to the remote repository works correctly. AI used: ChatGPT
access: I tested my GitHub access and confirmed that it works fine. I was able to access my repository and check that everything was working. This means I can use GitHub to store my project, upload changes, and keep track of my work. I would also need to make sure my teammates and instructor have the correct access before working together.  AI used: ChatGPT
video1: Observation: I learned that making mistakes is a normal part of game development. Instead of giving up, developers should learn from their mistakes and try again.

Useful Idea: Every mistake is an opportunity to improve your skills and become a better developer.

Question: What should a developer do when they keep running into problems while making a game? AI used: ChatGPT
video4: Observation: Something I found interesting is that a folder structure can help new people understand a project without having to ask someone where every file is located. Using README files to explain what each folder contains can make it easier for someone to start helping with the game.

Useful Idea: I could include a short README inside folders for things like audio, images, and scripts so another person knows exactly what belongs there and where to find it.

Question: What information should be included in a README so a new team member can understand a project without needing someone to explain everything? AI used: ChatGPT
video5: Observation: I learned that deciding where files are stored and how they are backed up should happen early in development. This is important because losing important game assets, such as character models, music, or artwork, could cause a lot of problems.

Useful Idea: Keeping original assets separate from exported versions would help prevent accidentally replacing or losing the files I might need to edit later.

Question: What is the safest way to back up large game files so they can still be recovered if something goes wrong? AI used: ChatGPT
video6: Observation: I found it interesting that game development involves more than just one program. Developers may use different tools for coding, creating 3D models, editing text, communicating, and finding audio resources.

Useful Idea: Keeping links to useful programs and resources in one organized document would save time instead of having to search for the same tools every time I work on the game.

Question: How do developers decide which programs are worth using together instead of trying to do everything in one program? AI used: ChatGPT
opinion: I could use the game development pipeline to create an adventure game based on a futuristic bounty hunter app. In the game, players would take on the role of a bounty hunter who uses an app to find targets, accept missions, and earn rewards. Each mission would have a different target, location, and set of challenges. Some targets might be criminals hiding in crowded cities, while others could be difficult to track down in remote locations. I could use the pipeline to organize mission details, character designs, maps, dialogue, and rewards. As players complete more jobs, they could earn money to upgrade their equipment and unlock harder missions. This would help me create a game with a clear progression system and an interesting world for players to explore. AI used: ChatGPT
questions: Before committing to a team or mission for my bounty hunter game, I would want to know what everyone's responsibilities are and what the mission requires. I would ask how the team communicates, how rewards are divided, and what happens if someone cannot complete their part. I would also want to know how difficult the mission is, what equipment is needed, and whether there are any risks or unexpected challenges. Having these questions answered beforehand would help prevent confusion, keep everyone working toward the same goal, and make missions run more smoothly. AI used: ChatGPT

# prepBoard
notes: AI used: ChatGPT

## pen
color: #153f48
size: 1

# pitch
understand: The job is to take my bounty hunter game idea and turn it into a working game that people can actually play. This means planning the missions, designing the characters and city, creating the bounty hunting app, and programming features like target tracking, rewards, and equipment upgrades. I would also need to test the game, fix bugs, and make sure missions work the way they are supposed to. The finish line is having a complete game where players can accept bounties, track down targets, complete missions, earn money, and use their rewards to improve their equipment. It is not just about having a good idea; it is about finishing a playable game that works. AI used: ChatGPT
offer: I can contribute creative ideas, help plan missions, and think of ways to make the bounty hunter game more interesting. I can help come up with different targets, mission objectives, rewards, and challenges for players to complete. I can also help organize the project, give feedback on ideas, and test the game to find problems. I would be willing to communicate with my teammates, listen to their suggestions, and help wherever I am needed to get the game finished. AI used: ChatGPT
limits: I still need to learn more about programming and how to build the different systems in my bounty hunter game. I would need to practice creating the bounty app, setting up missions, making targets move around the map, and programming the reward system. I also need to learn how to design maps and characters and add sound effects. Getting more experience with game development programs and learning how to fix coding errors would help me turn my ideas into an actual playable game. I would also benefit from guidance from teammates who have more experience with programming and game design. AI used: ChatGPT
availability: 2026-11-10 16:00–17:00 Pacific
2026-11-12 16:00–17:00 Pacific
2026-11-13 18:00–23:00 Pacific
2026-11-13 12:00–23:00 Pacific
Preferred contact: Classroom
tools: 1. XAML: I would use XAML to design the layout of the bounty hunter app, including buttons, menus, mission lists, and target information.

2. Unity: I would use Unity to create the actual game, build the city, program missions, and make the bounty hunting mechanics work.

3. Discord: I would use Discord to communicate with teammates, share ideas, send updates, and discuss problems during development.

4. Canvas: I would use Canvas to access class assignments, follow project instructions, submit completed work, and keep track of deadlines and feedback from my professor.

AI used: ChatGPT
aiTool: AI: ChatGPT and Claude
Task: I will use ChatGPT and Claude to brainstorm bounty hunting missions, create target descriptions, come up with game features, organize ideas, and help me understand coding problems while developing my game in Unity.
Verification: I will compare their suggestions, check that the information makes sense, and test any code in Unity to make sure it works. I will also make sure their ideas fit my game and correct anything that is inaccurate or does not work.

# availability
notes: 

## slots

### 0
id: b5834b46-b379-4008-b528-b6109c702ded
date: 2026-11-10
start: 16:00
end: 17:00

### 1
id: fc83f2d1-cddd-47eb-b231-a15cdc2c5186
date: 2026-11-12
start: 16:00
end: 17:00

### 2
id: 1819ee5e-7d3f-4f74-86f9-2fd110b51fcf
date: 2026-11-13
start: 18:00
end: 23:00

### 3
id: 2a803625-b01d-4bae-b903-008d895d14b1
date: 2026-11-13
start: 12:00
end: 23:00

# aiPlan
name: ChatGPT and Claude
task: I will use ChatGPT and Claude to brainstorm bounty hunting missions, create target descriptions, come up with game features, organize ideas, and help me understand coding problems while developing my game in Unity.
verify: I will compare their suggestions, check that the information makes sense, and test any code in Unity to make sure it works. I will also make sure their ideas fit my game and correct anything that is inaccurate or does not work.

# huddle
mission: We are going to convert the Bounty Hunting App into a game where the player will actually hunt for the criminals.
framework: We chose P2P.
pipeline: Unnamed stage
Unnamed stage
Unnamed stage
Unnamed stage
Unnamed stage
Unnamed stage
Placeholder · owner Bounty Sketch 
Placeholder · owner Connector
We put everything in order and used Claude Ai to give us the answers
tech: Engine: Unity. It’s free, lightweight, and has good beginner tutorials, so everyone can install it and start quickly.

Language: Unity C#. It’s built into Godot and easy to read, so teammates can understand each other’s code.

Packages/add-ons: Godot’s built-in 2D/3D tools (sprites, collision, UI nodes) so we don’t depend on extra downloads that might break.

Assets: Free, license-friendly art and sound (for example from Kenney.nl or OpenGameArt), plus our own wanted-poster designs made in Canva or Figma. We chose free assets so we don’t have copyright problems.

Who checks them:

[Leah Aluni] checks that the engine and code run on every team member’s computer.
[Nicolas Kuhnast] checks that every asset has a license that lets us use it.
[George Arbache] tests the finished build after each change.

Why we chose these: They’re free, beginner-friendly, and work well for a small team with limited time. Open question: Do we need any extra add-ons for saving scores, or is the built-in system enough? I used Claude to get the answer
code: Start / Update
Callback | What happens | Verified
Awake() | Sets up references (player, bounty list) before the game starts | [x]
Start() | Loads the first bounty and sets the score to 0 | [x]
Update() | Every frame: reads player input, moves the player, checks if the bounty is caught | [x]
OnCollisionEnter2D() | Runs when the player touches a bounty target, then adds the reward to the score | [x]

Classes & components
Class | Responsibility | GameObject
PlayerController | Reads input and moves the player; checks when the player touches a bounty | Player
BountyTarget | Stores each target’s name, difficulty, and reward value | Bounty (prefab)
GameManager | Tracks the score and which bounty is active; decides when the game ends | GameManager (empty object)
UIManager | Updates the score text and shows the win or game over screen | Canvas

Packages / using
Package / namespace | Why included | Tested
using UnityEngine; | Gives access to the core engine tools our scripts need, like MonoBehaviour, Transform, Input, and Vector2 | [x]
using UnityEngine.UI; | Lets us update the score text and buttons on the screen from code | [x]
using System.Collections.Generic; | Lets us use List<> to store the bounty list and loop through it | [x]
using UnityEngine.SceneManagement; | Lets us reload the scene when the player restarts after winning or losing | [x]
communication: Team check-ins
Description / contact / owner | When · Pacific | Agreed
George Arbache  | 2026-11-10T15:48 | [x]
reuse: PlayerController script (our own code). Source: written by our team. Credit: none required, but we’ll keep our names in the code comments.
GameManager and score system (our own code). Source: written by our team. Credit: none required. It can be reused for any game that tracks points or objectives.
Bounty data structure (BountyTarget class). Source: our team. Credit: none required. We can swap in new characters, rewards, and difficulty levels for a new story.
Free art and sound assets (for example from Kenney.nl or OpenGameArt). Source: the website and creator’s name, saved in a credits file. Credit: we’ll check each license, since some (CC0) need no credit and others (CC-BY) require us to name the creator.
Our wanted-poster and menu designs (Canva or Figma). Source: our team. Credit: if we used Canva templates or stock elements, we’ll check Canva’s license terms before reusing them. I used Claude for my answer.
boardNotes: What the huddle board is: A shared space where our team writes down what we discussed, what we agreed on, and what we still need to figure out, so nobody has to rely on memory and everyone can see the same plan.

Decisions we made:

We will build the game in [Godot/Unity] using [GDScript/C#], because it’s free and beginner-friendly.
We will keep the game small: at least 3 bounties, a score system, and a win or game over screen.
We will use free, license-friendly assets and keep a credits file listing each source.
Each person owns one part of the pipeline: [Name 1] inputs, [Name 2] building, [Name 3] design, [Name 4] testing.

Disagreements:

Some of us wanted more bounties and extra levels, while others wanted to finish a smaller game that works. We agreed to finish 3 bounties first and add more only if time is left.
We discussed whether to draw our own art or use free assets. We chose free assets for the characters and made our own wanted posters.

Questions that remain open:

Do we need an extra add-on to save high scores, or is the built-in system enough?
Who will double-check that every asset’s license allows us to reuse it?
How many classmates can test the game before the deadline? I used Claude to get the answers

## board
notes: Our mission is to build a playable bounty hunting game with at least three bounties, a score system, and a win or game over screen. In our huddle we compared our ideas for the mission and agreed to keep the game small so we can finish it.

The diagram shows the mission at the top, connected to three jobs. [Name 1] builds the game and scoring. [Name 2] designs the posters, menus, and art. [Name 3] tests the game, keeps the bug list, and checks that every asset’s license lets us use it. All three jobs lead to the finished prototype at the bottom.

We decided that each person owns one job so nothing is missed, and that we will check in again before the deadline. One disagreement was whether to add more bounties or finish a smaller game first, and we chose to finish three bounties first. One open question is how we will save high scores. we used claude to get the answers

## pipelineBoard
notes: We put everything in order and used Claude Ai to give us the answers

## codeTables

### 0
id: f755df56-99d0-432a-9e1f-74ecc1902297
title: Start / Update

#### columns

##### 0
label: Callback
type: text

##### 1
label: What happens
type: text

##### 2
label: Verified
type: checkbox

#### rows

##### 0
0: Awake()
1: Sets up references (player, bounty list) before the game starts
2: true

##### 1
0: Start()
1: Loads the first bounty and sets the score to 0
2: true

##### 2
0: Update()
1: Every frame: reads player input, moves the player, checks if the bounty is caught
2: true

##### 3
0: OnCollisionEnter2D()
1: Runs when the player touches a bounty target, then adds the reward to the score
2: true

### 1
id: c0b5405d-1eba-4c5e-8cd3-c3785ef3b8e8
title: Classes & components

#### columns

##### 0
label: Class
type: text

##### 1
label: Responsibility
type: text

##### 2
label: GameObject
type: text

#### rows

##### 0
0: PlayerController
1: Reads input and moves the player; checks when the player touches a bounty
2: Player

##### 1
0: BountyTarget
1: Stores each target’s name, difficulty, and reward value
2: Bounty (prefab)

##### 2
0: GameManager
1: Tracks the score and which bounty is active; decides when the game ends
2: GameManager (empty object)

##### 3
0: UIManager
1: Updates the score text and shows the win or game over screen
2: Canvas

### 2
id: 964a5672-74ca-40a8-8427-ccc9b1295e38
title: Packages / using

#### columns

##### 0
label: Package / namespace
type: text

##### 1
label: Why included
type: text

##### 2
label: Tested
type: checkbox

#### rows

##### 0
0: using UnityEngine;
1: Gives access to the core engine tools our scripts need, like MonoBehaviour, Transform, Input, and Vector2
2: true

##### 1
0: using UnityEngine.UI;
1: Lets us update the score text and buttons on the screen from code
2: true

##### 2
0: using System.Collections.Generic;
1: Lets us use List<> to store the bounty list and loop through it
2: true

##### 3
0: using UnityEngine.SceneManagement;
1: Lets us reload the scene when the player restarts after winning or losing
2: true

## communicationTables

### 0
id: 94fbcf11-58d1-405b-b8c3-f121cee8b18c
title: Team check-ins

#### columns

##### 0
label: Description / contact / owner
type: text

##### 1
label: When · Pacific
type: datetime-local

##### 2
label: Agreed
type: checkbox

#### rows

##### 0
0: George Arbache 
1: 2026-11-10T15:48
2: true

# huddleBoard
notes: Our mission is to build a playable bounty hunting game with at least three bounties, a score system, and a win or game over screen. In our huddle we compared our ideas for the mission and agreed to keep the game small so we can finish it.

The diagram shows the mission at the top, connected to three jobs. [Name 1] builds the game and scoring. [Name 2] designs the posters, menus, and art. [Name 3] tests the game, keeps the bug list, and checks that every asset’s license lets us use it. All three jobs lead to the finished prototype at the bottom.

We decided that each person owns one job so nothing is missed, and that we will check in again before the deadline. One disagreement was whether to add more bounties or finish a smaller game first, and we chose to finish three bounties first. One open question is how we will save high scores. we used claude to get the answers

# pipelineBoard
notes: We put everything in order and used Claude Ai to give us the answers

# codeTables

## 0
id: f755df56-99d0-432a-9e1f-74ecc1902297
title: Start / Update

### columns

#### 0
label: Callback
type: text

#### 1
label: What happens
type: text

#### 2
label: Verified
type: checkbox

### rows

#### 0
0: Awake()
1: Sets up references (player, bounty list) before the game starts
2: true

#### 1
0: Start()
1: Loads the first bounty and sets the score to 0
2: true

#### 2
0: Update()
1: Every frame: reads player input, moves the player, checks if the bounty is caught
2: true

#### 3
0: OnCollisionEnter2D()
1: Runs when the player touches a bounty target, then adds the reward to the score
2: true

## 1
id: c0b5405d-1eba-4c5e-8cd3-c3785ef3b8e8
title: Classes & components

### columns

#### 0
label: Class
type: text

#### 1
label: Responsibility
type: text

#### 2
label: GameObject
type: text

### rows

#### 0
0: PlayerController
1: Reads input and moves the player; checks when the player touches a bounty
2: Player

#### 1
0: BountyTarget
1: Stores each target’s name, difficulty, and reward value
2: Bounty (prefab)

#### 2
0: GameManager
1: Tracks the score and which bounty is active; decides when the game ends
2: GameManager (empty object)

#### 3
0: UIManager
1: Updates the score text and shows the win or game over screen
2: Canvas

## 2
id: 964a5672-74ca-40a8-8427-ccc9b1295e38
title: Packages / using

### columns

#### 0
label: Package / namespace
type: text

#### 1
label: Why included
type: text

#### 2
label: Tested
type: checkbox

### rows

#### 0
0: using UnityEngine;
1: Gives access to the core engine tools our scripts need, like MonoBehaviour, Transform, Input, and Vector2
2: true

#### 1
0: using UnityEngine.UI;
1: Lets us update the score text and buttons on the screen from code
2: true

#### 2
0: using System.Collections.Generic;
1: Lets us use List<> to store the bounty list and loop through it
2: true

#### 3
0: using UnityEngine.SceneManagement;
1: Lets us reload the scene when the player restarts after winning or losing
2: true

# communicationTables

## 0
id: 94fbcf11-58d1-405b-b8c3-f121cee8b18c
title: Team check-ins

### columns

#### 0
label: Description / contact / owner
type: text

#### 1
label: When · Pacific
type: datetime-local

#### 2
label: Agreed
type: checkbox

### rows

#### 0
0: George Arbache 
1: 2026-11-10T15:48
2: true

# tasks

## 0
id: e9fcadfb-346c-4e46-81be-35b6fba97260
task: make assest
owner: PERSON-2CF9BDAD78338B9BDDA6928E
due: 2026-11-12T20:30
done: false
result: 

## 1
id: ab8b7007-c585-474b-b404-450d07460f53
task: do the coding
owner: PERSON-2CF9BDAD78338B9BDDA6928E
due: 2026-11-12T20:30
done: false
result: 

## 2
id: 5019ca2c-a540-4466-82bc-74fac46c30e6
task: Organize information
owner: PERSON-C74E56D4FBB64FE2EB6D0CC8
due: 2026-11-12T20:30
done: false
result: 

# previousTeamPlans

## 0
team: TEAM-BE6A42D9973ABA2940DFA478
name: Human Systems Check

### huddle
mission: A Bounty Hunter in a cyberpunk type world hunting down all the bounties he can of different creatures
framework: P2P
pipeline: Story goal · 2026-11-10T12:45 to 2026-11-10T13:45 Pacific
Inputs / assets · 2026-11-10T13:45 to 2026-11-10T14:45 Pacific
Build + configure · 2026-11-10T14:45 to 2026-11-10T15:45 Pacific
Output / scene · 2026-11-10T15:45 to 2026-11-10T16:45 Pacific
Test + handoff · 2026-11-10T16:45 to 2026-11-10T17:45 Pacific
New stage · 2026-11-10T17:45 to 2026-11-10T18:45 Pacific
New stage · 2026-11-10T18:45 to 2026-11-10T19:45 Pacific
We are going to make a Pathways to pipelines 
type game
tech: Unity, C#, Characters
code: Classes & components
Class | Responsibility | GameObject
te | te | te
communication: Working agreements
Agreement | Owner / where recorded | Confirmed
te | te | [ ]
reuse: The assets
boardNotes: We explained everyone works

#### board
notes: Make a AR Game that helps others catch bounties and try to get the best version of that creature

#### pipelineBoard
notes: We are going to make a Pathways to pipelines 
type game

#### codeTables

##### 0
id: 33d6291c-2d2f-4be6-8eef-def08a5fbba1
title: Classes & components

##### columns

##### 0
label: Class
type: text

##### 1
label: Responsibility
type: text

##### 2
label: GameObject
type: text

##### rows

##### 0
0: te
1: te
2: te

#### communicationTables

##### 0
id: 2a432ee5-bb48-456c-9515-9c5b2832b853
title: Working agreements

##### columns

##### 0
label: Agreement
type: text

##### 1
label: Owner / where recorded
type: text

##### 2
label: Confirmed
type: checkbox

##### rows

##### 0
0: te
1: te
2: false

### huddleBoard
notes: Make a AR Game that helps others catch bounties and try to get the best version of that creature

### pipelineBoard
notes: We are going to make a Pathways to pipelines 
type game

### codeTables

#### 0
id: 33d6291c-2d2f-4be6-8eef-def08a5fbba1
title: Classes & components

##### columns

##### 0
label: Class
type: text

##### 1
label: Responsibility
type: text

##### 2
label: GameObject
type: text

##### rows

##### 0
0: te
1: te
2: te

### communicationTables

#### 0
id: 2a432ee5-bb48-456c-9515-9c5b2832b853
title: Working agreements

##### columns

##### 0
label: Agreement
type: text

##### 1
label: Owner / where recorded
type: text

##### 2
label: Confirmed
type: checkbox

##### rows

##### 0
0: te
1: te
2: false

### tasks

#### 0
id: 21d08324-4500-4823-bd60-db6c5a0d782e
task: 
owner: PERSON-0134466E7594E128639BDB00
due: 2026-11-12T20:30
done: false
result: 

# dayBReview
recap: I understand that our goal is to turn the Bounty Hunting App into a video game where players can find, chase, and capture criminals. My job is to help my team plan, design, and program the game, especially player movement and capturing criminals. We will organize our tasks using a project board and track our progress. I still need to clarify how the game mechanics will work, which tools we will use, and what each teammate will be responsible for.
goal: true
owners: true
blockers: true
notes: Nothng so far.
returnToB: false

# reportA
checkpoint: I understand that our goal is to turn the Bounty Hunting App into a video game where players can hunt down and catch criminals. My job is to help plan, design, and program the game with my team. We need to figure out how the player will move, find criminals, and capture them. One question I have is what programming tools we will use and how the game mechanics will work.
evidence: I worked on planning our Bounty Hunting Game, where players will search for and capture criminals. I helped identify the main goals and features we want in the game. We still need to organize our tasks and decide how to program the gameplay. My next step is to save my work to GitHub and record the commit link along with our notes and team documents.
next: My next task is to help develop the Bounty Hunting Game by working on player movement and criminal capture mechanics. I plan to complete my next task before our next class deadline. One possible blocker is figuring out how to code certain features. If I get stuck, I will review tutorials, ask my teammates for help, and test different solutions.

# reportABoard
notes: The Bounty Hunting Game Board is a visual plan showing what your team wants to create, what needs to be done, and how you will organize the work.
1. Project Goal
Your team is turning the Bounty Hunting App into a video game where players search for criminals, chase them, and capture them.
2. My Recap
This section explains your understanding of the project and your responsibilities. Your job is to help plan, design, and program the game with your teammates.
3. Team Board (Kanban)
The four columns organize the project's progress:
- To Do: Tasks that haven't been started, such as designing criminals, creating the map, and adding game features.
- In Progress: Tasks currently being worked on, such as player movement and capturing criminals.
- Review/Testing: Features that need to be tested to make sure they work.
- Done: Planning activities that have been completed.
4. Next Task and Plan
Your next task is to work on player movement and criminal capture mechanics before the next class deadline.

If you encounter programming problems, you can watch tutorials, ask teammates for help, or try different solutions.
5. Team Roles
The board suggests dividing responsibilities among teammates, including programming, game design, map creation, and testing. These are proposed roles, not confirmed assignments.
6. Tools and Resources
The board includes Unity for creating the game, C# for programming, GitHub for saving code, and shared documents for recording progress.

Important: The board is a proposed project plan. Tasks shown as completed or in progress should be updated to match what your team has actually done. AI used: ChatGPT

## pen
color: #153f48
size: 1

# reportB
execution: I created a project board for our Bounty Hunting Game that organizes our goals, tasks, team responsibilities, and next steps. The board includes tasks such as player movement, criminal capture mechanics, map design, and testing. I also identified possible programming challenges and ways to solve them. Our next step is to begin developing the game and testing its basic features.
tests: I created a project board for our Bounty Hunting Game and organized the tasks needed to develop it. The board includes player movement, criminal capture, map design, and testing. I have not tested the actual game yet, so I still need to confirm that the project opens and runs correctly, check the player controls, and record the results. If something fails, I will identify the problem, make changes, and test it again. My next step is to build and test the basic gameplay features.
handoff: I created a project board for our Bounty Hunting Game that explains our goals, tasks, responsibilities, and development plan. The board includes player movement, criminal capture, map design, and testing. I have organized the information so my teammates can understand the project and what needs to be completed. I still need to upload our project files to GitHub, save the board with our documentation, and add instructions for opening and running the game.
reflection: I created a project board for our Bounty Hunting Game and compared it with our original goal of making a game where players hunt and capture criminals. I verified that our plan includes the main features we need, such as player movement, criminal capture, map design, and testing. We still need to build and test these features to make sure they work. One useful discovery is that organizing tasks helps us understand what needs to be done. Our team's next step should be to create a playable version of the game, test it, and fix any problems we find.

# reportBBoard
notes: This image shows the project board I created for our Bounty Hunting Game. It explains our goal of making a game where players hunt down and capture criminals. I organized the work into tasks that need to be completed, tasks planned for development, testing, and completed planning activities. The board also includes proposed team responsibilities and the tools we may use. My main focus is helping develop player movement and criminal capture mechanics. This board helps us understand our next steps and stay organized while building the game. AI used: ChatGPT